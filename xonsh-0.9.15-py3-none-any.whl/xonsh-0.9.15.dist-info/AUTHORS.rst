All of the people who have made at least one contribution to xonsh.
Authors are sorted by number of commits.

* Anthony Scopatz
* Adam Hartz
* Gil Forsyth
* Morten Enemark Lund
* Konstantinos Tsakiltzidis
* Jamie Bliss
* Hugo Wang
* BlahGeek
* Bob Hyman
* Jean-Benoist Leger
* christopher
* Klaus Alexander Seistrup
* David Strobach
* Leonardo Santagada
* Burak Yiğit Kaya
* Aaron Griffin
* Rob Brewer
* virus
* Sagar Tewari
* Matthias Bussonnier
* Konstantin Molchanov
* Guillaume Leclerc
* Gordon Ball
* Travis Shirk
* Joel Gerber
* anki-code
* vaaaaanquish
* Bernardas Ališauskas
* Derek Thomas
* David Dotson
* VHarisop
* JohnLunzer
* Paul Goelz
* Carmen Bianca Bakker
* Frank Sachsenheim
* Kurtis Rader
* cryzed
* Brian Visel
* Andrew Hundt
* Jonathan Slenders
* Justin Moen
* con-f-use
* Caleb Hattingh
* Stephan Fitzpatrick
* Raphael Das Gupta
* K.-Michael Aye
* Jason R. Coombs
* halloleo
* Will Wykeham
* Oleh Prypin
* Brian Skinn
* Will S
* Alessio Bogon
* Yohei Tamura
* Maximilian Köhl
* Cody Scott
* Jake Hedman
* Alexander Sosedkin
* traverseda
* Andre Weltsch
* Jeremy Donahue
* Raphael Gaschignard
* Nathan Goldbaum
* mel
* Jared Crawford
* Mike Crowe
* JuanPablo
* Ollie Terrance
* Marcel Bollmann
* mdraw
* Mattias Ugelvik
* Ryan Gonzalez
* David Gros
* Andrea D'Amore
* James Elías
* anula
* Jay Tuckey
* Alexander Steffen
* Randy Syring
* Lucas Inojosa
* adam j hartz
* Nickolay Bukreyev
* Alexey
* Alexandre Ferland
* Marvin Steadfast
* Aaron Meurer
* Matteo Bertini
* anatoly techtonik
* AaronV77
* Erick Tucto
* Tyler Goodlet
* Paul Barton
* 74th
* Mickaël Schoentgen
* Steven Silvester
* Robert DeFriesse
* Justin Calamari
* Thomas Marquart
* Benjamin Pollack
* Sardorbek Imomaliev
* Jakub Nowak
* selepo
* Fabien Dubosson
* Kale Kundert
* Andrés García García
* Sean Farley
* Jan Schulz
* Samuel Dion-Girardeau
* Michael Droettboom
* guillearch
* javValverde
* Shahin
* Nico Lehmann
* Sebastian Wagner
* yuqing
* Rahiel Kasim
* SanketDG
* David
* Danmou
* Niklas Hambüchen
* Sébastien Pierre
* shadow-light
* Jan Chren
* Samuel Lotz
* Mark Wiebe
* Nathan Hoad
* Eric Dill
* neruok
* Domenic Barbuzzi
* metamind
* Qiushi Pan
* josh
* TobalJackson
* Greg Thole
* Min RK
* Nicolas Avrutin
* Kevin Yokley
* Ollie Ford
* Mark Bestley
* Michał Zając
* Emre Ates
* Romain Bignon
* Owen Campbell
* Steven Kryskalla
* cclauss
* Eddie Peters
* Gyuri Horak
* Ke Zhang
* László Vaskó
* Allan Crooks
* micimize
* Edmund Miller
* Noortheen Raja
* Gabriel Vogel
* anki
* Dan Allan
* Ned Letcher
* Zach Crownover
* Miguel de Val-Borro
* Hirotomo Moriwaki
* Phil Elson
* Erin Call
* Trevor Bekolay
* Tzu-ping Chung
* Andrew Toskin
* torgny
* William Woodall
* ariel faigon
* Nigel Tea
* Mark Szumowski
* The Gitter Badger
* Cameron Bates
* Kermit Alexander II
* Richard Kim
* Brian S. Corbin
* Erez Shinan
* Nakada Takumi
* Ross Nomann
* eyalzek
* Pedro Rodriguez
* Eric Harris
* Austin Bingham
* jlunz
* dragon788
* Jonathan Hogg
* Andrei
* Daniel Hahler
* Mark Harfouche
* Carol Willing
* Kilte Leichnam
* Raniere Silva
* Thomas Kluyver
* Donne Martin
* Alexey Shrub
* Jean-Christophe Fillion-Robin
* Charlie Arnold
* Nate Tangsurat
* Michael Ensslin
* dbxnr
* sushobhana
* Florian Mounier
* Glen Zangirolami
* adamheins
* Joseph Paul
* Daniel Milde
* Katriel Cohn-Gordon
* Chad Kennedy
* stonebig
* Ronny Pfannschmidt
* Troy de Freitas
* Rodrigo Oliveira
* Daniel Smith
* Nils ANDRÉ-CHANG
* chengxuncc
* nedsociety
* fanosta
* David Kalliecharan
* Sylvain Corlay
* Chris Lasher
* Marcio Mazza
* Jerzy Drozdz
* goodboy
* Atsushi Morimoto
